s
compiler environments
Microsoft Visual Studio (or Express)
 !D"  0,  =H   ]
Sun cc - Solaris
  @V  ,@  .N  !?
gcc - generic
  1V  -W  /   !^
gcc - generic - Insight debugger
  _>  -T  1@  "P
gcc - MinGW - OpenGL32 with freeglut
 ":Z  -]  9H  #F
gcc - generic - OpenGL with GLUT
 "!J  .<  90  $8
cc (gcc) - Mac OS X
  OD  +Z  /Z  $]
DJGPP2
 !0^  ,C  3$  %5
Borland BCC 5.5 - Windows
      ,[  1V  & 
clang - generic
 "TB  -]  :&  &A

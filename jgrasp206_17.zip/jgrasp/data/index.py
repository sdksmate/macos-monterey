s
compiler environments
Python 2 - Enthought Canopy
      &X  -P   T
Python 2 - generic
  -P  &W  -N  !8
Python 3 (python3) - generic
  ;>  &Y  -R  "&
Python 3 - generic
  I0  &W  -N  "J

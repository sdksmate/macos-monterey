## What's New

- [x] Fix manual update command not showing the "No updates" screen - #7

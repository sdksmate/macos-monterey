package jgrasp_viewers;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import javax.swing.JPanel;
import jgrasp.Colors;
import jgrasp.Drawing;
import jgrasp.PluginOptOut;
import jgrasp.viewer.IndexItem;
import jgrasp.viewer.PaintUtil;
import jgrasp.viewer.Sizes;
import jgrasp.viewer.ViewerCreateData;
import jgrasp.viewer.ViewerException;
import jgrasp.viewer.ViewerInfo;
import jgrasp.viewer.ViewerInitData;
import jgrasp.viewer.ViewerPriorityData;
import jgrasp.viewer.ViewerUpdateData;
import jgrasp.viewer.ViewerValueData;
import jgrasp.viewer.ViewerRoot;
import jgrasp.viewer.gui.ValueDragData;
import jgrasp.viewer.gui.ValueDragger;
import jgrasp.viewer.jgrdi.DebugContext;
import jgrasp.viewer.jgrdi.Method;
import jgrasp.viewer.jgrdi.Type;
import jgrasp.viewer.jgrdi.Value;
import org.w3c.dom.Element;


/** A viewer that displays color bars for arrays and lists of int, Integer, or Color type. **/
public class java__lang__Object_ColorBarView extends ViewerRoot {

   /** State data. **/
   public static class Data {
   
      /** The object value. **/
      private Value obj;
   
      /** The current values. **/
      private List<Integer> values;
   
      /** Changed state for each value. **/
      private List<Boolean> changed;
   
      /** New state for each value. **/
      private List<Boolean> isNew;
   
      /** True if the data was derived from an array type, false if it came from a list. **/
      private boolean isArray;
   
      /** Index expressions. This may be null. **/
      private List<IndexItem> indexes;
   }

   /** Supported element types. **/
   private static final Collection<String> supportedTypes = new HashSet<>();

   static {
      supportedTypes.add("int");
      supportedTypes.add("java.lang.Integer");
      supportedTypes.add("java.awt.Color");
   }

   /** Current state data. **/
   private Data stateData;

   /** Current font height in pixels. **/
   private int fontHeight;

   /** Drawing base unit, in pixels. **/
   private int margin;

   /** Height of index pointers. **/
   private int pointerLen;

   /** Current default size. **/
   private Dimension mainSize;

   /** Rectangle for first bar. **/
   private Rectangle barRect;

   /** Current selected value, or null if there is no selection. **/
   private Value selVal;

   /** Current selected index, or -1 if there is no selection. **/
   private int selInd = -1;


   /** Creates a new bar graph viewer.
    *
    * @param vcd viewer creation data. **/
   public java__lang__Object_ColorBarView(final ViewerCreateData vcd) {
      super(false, vcd.supportsSubViewers() ? EnumSet.of(CreationFlags.SUBVIEWER)
            : EnumSet.noneOf(CreationFlags.class));
      Value v = vcd.getValue();
      DebugContext dc = vcd.getDebugContext();
      Type t = v.getType(dc);
      try {
         if (!t.isArray(dc)) {
            if (v.isInstanceOf(dc, "java.util.List")) {
               return;
            }
         }
         else {
            Type elementType = t.getArrayElementType(dc);
            String tName = elementType.getName(dc);
            if (supportedTypes.contains(tName) || "java.lang.Object".equals(tName)) {
               return;
            }
         }
      }
      catch (ViewerException ignored) {
      }
      throw new PluginOptOut();
   }


   /** {@inheritDoc} **/
   @Override
   public void build(final ViewerInitData vid, final Element initDataIn) {
      super.build(vid, initDataIn);
      vid.setIndexable(true);
   }


   /** {@inheritDoc} **/
   @Override
   public void configure() {
      Data currentData = stateData;
      if (currentData == null) {
         return;
      }
   
      JPanel mp = getMainPanel();
      Graphics2D g = (Graphics2D) mp.getGraphics();
      if (g == null) {
         return;
      }
      setBaseTransformAndAdjust(g);
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
   
      g.setFont(mp.getFont());
      FontMetrics fm = g.getFontMetrics();
      fontHeight = fm.getHeight();
      margin = (fm.getHeight() + 3) / 4;
      List<Integer> currentValues = currentData.values;
      if (currentValues == null) {
         return;
      }
      int w = Math.max(50, currentValues.size()) * margin;
      int labelHeight = margin * 2 + fm.getHeight();
      int h = margin * 10 + labelHeight;
      if (currentData.indexes != null) {
         // Marker space.
         h += pointerLen * 2 + margin * 2;
         // Label space.
         h += fontHeight * currentData.indexes.size();
      }
   
      Dimension size = new Dimension(w, h);
      boolean sizeChanged = false;
      if (!size.equals(mainSize)) {
         mainSize = size;
         sizeChanged = true;
      }
      int minHeight = margin * 5 + labelHeight;
   
      pointerLen = (fontHeight + 2) / 4;
   
      if (currentData.indexes != null) {
         // Marker space.
         minHeight += pointerLen * 2 + margin * 2;
         // Label space.
         minHeight += fontHeight * currentData.indexes.size();
      }
   
      int count = currentValues.size();
      Dimension minSize = new Dimension(count + 2 * margin, minHeight);
   
      drawingToJava(minSize);
      if (!mp.getPreferredSize().equals(minSize)) {
         mp.setPreferredSize(minSize);
         sizeChanged = true;
      }
      if (sizeChanged) {
         mp.revalidate();
         mp.validate();
      }
      mp.repaint();
   }


   /** {@inheritDoc} **/
   @Override
   public void getInfo(final ViewerInfo vi) {
      vi.setShortDescription("Viewer for int, Integer, and java.awt.Color arrays and lists");
      vi.setLongDescription("This viewer displays arrays and java.util.List as bars of color using the color of each "
            + "value if the value is a java.awt.Color, or it's corresponding argb color if it's an int or integer.");
   }


   /** {@inheritDoc} **/
   @Override
   public Dimension getMainSize() {
      return mainSize;
   }


   /** {@inheritDoc} **/
   @Override
   public String getMainToolTipText(final MouseEvent e) {
      Data currentData = stateData;
      if (currentData == null || barRect == null) {
         return null;
      }
      Point pt = e.getPoint();
      javaToDrawing(pt);
      if (pt.y < barRect.y || pt.y > barRect.y + barRect.height) {
         return null;
      }
      int ind = (pt.x - barRect.x) / barRect.width;
      if (ind < 0) {
         return null;
      }
      if (ind >= currentData.values.size()) {
         return null;
      }
      int argb = currentData.values.get(ind).intValue();
      String val = (((argb & 0xff000000) != 0xff000000) ? "Alpha = " + (argb >> 24) + ", " : "") + "R = "
            + ((argb & 0xff0000) >> 16) + ", G = " + ((argb & 0xff00) >> 8) + ", B = " + (argb & 0xff);
      if (currentData.isArray) {
         return "[" + ind + "] = " + val;
      }
      return "<" + ind + "> = " + val;
   }


   /** {@inheritDoc} **/
   @Override
   public int getPriority(final ViewerPriorityData vpd) {
      Value v = vpd.getValue();
      DebugContext context = vpd.getDebugContext();
      try {
         if (v == null) {
            return Integer.MIN_VALUE;
         }
         Type type = v.getType(context);
         if (!type.isArray(context)) {
            if (v.isInstanceOf(context, "java.util.List")) {
               return -10;
            }
            return Integer.MIN_VALUE;
         }
         Type elementType = type.getArrayElementType(context);
         String elementTypeName = elementType.getName(context);
         if (!supportedTypes.contains(elementTypeName) && !"java.lang.Object".equals(elementTypeName)) {
            return Integer.MIN_VALUE;
         }
      }
      catch (ViewerException e) {
         return Integer.MIN_VALUE;
      }
      return -10;
   }


   /** {@inheritDoc} **/
   @Override
   public String getViewName() {
      return "Color Bars";
   }


   /** {@inheritDoc} **/
   @Override
   public void paintMainView(final Graphics2D graphics, final JPanel paintPanel) {
      AffineTransform prevTransform = graphics.getTransform();
      setBaseTransform(graphics);
      
      int l = Sizes.getVeryThinEdge(fontHeight);
      float lOffs = (l % 2) / 2.0f;
      if (!isViewerTransparent()) {
         graphics.setColor(Drawing.getColor(Colors.OUTLINE));
         int ppw = javaToDrawingW(paintPanel.getWidth());
         int pph = javaToDrawingH(paintPanel.getHeight());
         graphics.fillRect(0, 0, ppw, pph);
         if (paintPanel.getWidth() > l + l) {
            graphics.setColor(Drawing.getColor(Colors.BG));
            graphics.fillRect(l, l, ppw - l - l, pph - l - l);
         }
      }
      Data currentData = stateData;
      List<Integer> currentValues = currentData.values;
      if (currentValues == null) {
         return;
      }
   
      graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
   
      Dimension viewSize = paintPanel.getSize();
      javaToDrawing(viewSize);
      graphics.setFont(scaleFont(paintPanel.getFont()));
      FontMetrics fm = graphics.getFontMetrics();
      int fontAscent = fm.getAscent();
   
      int ht = viewSize.height - margin * 4 - fontAscent - fontAscent / 2;
      if (currentData.indexes != null) {
         // Marker space.
         ht -= (graphics.getFontMetrics().getHeight() + 2) / 4;
         ht -= margin * 2;
         // Label space.
         ht -= graphics.getFontMetrics().getHeight() * currentData.indexes.size();
      }
      if (ht < margin) {
         ht = margin;
      }
   
      List<Boolean> changed = currentData.changed;
      List<Integer> values = currentData.values;
   
      int zeroLine;
      int numberLine;
      int markerLine;
      zeroLine = margin + ht + fontAscent / 2;
      numberLine = zeroLine;
      markerLine = numberLine + fontHeight + margin * 2;
   
      int w = viewSize.width - margin - margin;
      int size = currentValues.size();
      if (w < size) {
         w = size;
      }
   
      int maxLabelLen = (int) Math.log10(Math.max(1, size - 1)) + 1;
      int maxLabelW = (int) Math.ceil(
            fm.getStringBounds("000000000000000000", 0, Math.min(18, maxLabelLen), graphics).getWidth());
      int barW = size > 0 ? w / size : 0;
   
      int minLabelSep = (int) Math.ceil((maxLabelW + margin) / (double) barW);
      if (minLabelSep < 1) {
         minLabelSep = 1;
      }
      // Label on the 5s or the 10s.
      int label10Sep = (int) Math.ceil(Math.pow(10, Math.ceil(Math.log10(minLabelSep))));
      int label5Sep = 5 * (int) Math.ceil(Math.pow(10, Math.ceil(Math.log10(minLabelSep) - Math.log10(5))));
      int labelSep = Math.min(label10Sep, label5Sep);
   
      int halfMargin = margin / 2;
      int x = margin;
      graphics.setColor(Drawing.getColor(Colors.FG));
      graphics.setStroke(new BasicStroke(l, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 2.0f));
   
      barRect = new Rectangle(x, zeroLine -ht, barW, ht);
   
      startBarPaint();
      Rectangle2D.Double selRect = null;
      for (int v = 0; v < size; v++, x += barW) {
         int barH;
         int val = values.get(v).intValue();
         boolean ch = changed != null && changed.get(v).booleanValue();
         boolean isNew = currentData.isNew != null && currentData.isNew.get(v).booleanValue();
         barH = ch ? (ht * 2 + 1) / 3 : (isNew ? (ht + 1) / 3 : ht);
         int y = zeroLine - barH;
         if (ch) {
            changedValue(v, size, val);
         }
         graphics.setColor(new Color(currentValues.get(v).intValue()));
         Rectangle2D.Double rect = new Rectangle2D.Double(x + (barW == 1 ? 1 : 0) + lOffs, y + lOffs, barW, barH);
         if (v == selInd) {
            selRect = new Rectangle2D.Double(rect.x, barRect.y, barW, barRect.height);
         }
         graphics.fill(rect);
         if (barW > 1) {
            graphics.setColor(Drawing.getColor(Colors.OUTLINE));
            rect.height = l;
            graphics.draw(rect);
         }
      
         if (v % labelSep == 0) {
            String label = String.valueOf(v);
            int labelWidth = (label.isEmpty())? 0
                  : (int) Math.ceil(fm.getStringBounds(label, graphics).getWidth());
            int linePos = x + barW / 2;
            graphics.setColor(Drawing.getColor(Colors.FG));
            y = numberLine + fontAscent + margin * 2;
            graphics.draw(new Line2D.Float(linePos + lOffs, numberLine + halfMargin + lOffs, linePos + lOffs,
                  numberLine + margin + halfMargin + lOffs));
            graphics.drawString(label, (int) (x + barW / 2.0 - labelWidth / 2.0), y);
         }
      }
      Drawing.drawSelectionRect(graphics, selRect, l);
      endBarPaint();
      graphics.setColor(Drawing.getColor(Colors.FG));
      graphics.draw(new Line2D.Float(margin + lOffs, zeroLine + lOffs,
            margin + barW * size + lOffs, zeroLine + lOffs));
      graphics.draw(new Line2D.Float(margin + lOffs, zeroLine - ht + lOffs, margin + lOffs, zeroLine + lOffs));
   
      if (currentData.indexes != null) {
         int[] xCenters = new int[size];
         for (int i = 0; i < size; i++) {
            xCenters[i] = margin + i * barW + barW / 2;
         }
         PaintUtil.paintHorizontalIndexes(graphics, xCenters, markerLine, margin, viewSize.width - margin, pointerLen,
               currentData.indexes, 0);
      }
      graphics.setTransform(prevTransform);
   }


   /** {@inheritDoc} **/
   @Override
   public void updateState(final ViewerValueData valueData, final ViewerUpdateData data, final DebugContext context)
         throws ViewerException {
      Data oldData = stateData;
      Value value = valueData.getValue();
      Type type = value.getType(context);
      Data newData = new Data();
      newData.obj = value;
      if (!type.isArray(context)) {
         if (value.isInstanceOf(context, "java.util.List")) {
            Method toArrayMethod = type.getMethod(context, "toArray", "java.lang.Object[]", null);
            value = value.invokeMethod(context, toArrayMethod, null);
            type = value.getType(context);
         }
         else {
            stateData = newData;
            return;
         }
      }
      else {
         newData.isArray = true;
      }
      Type elementType = type.getArrayElementType(context);
      boolean isObject = elementType.isObject(context);
   
      int len = value.getArrayLength(context);
      boolean isOneFloat = false;
      List<Integer> newValues = null;
      Method intValue = null;
      Type lastType = null;
      List<Value> values = value.getArrayElements(context, 0, len);
      selVal = null;
      for (int d = 0; d < len; d++) {
         Value v = values.get(d);
         if (d == selInd) {
            selVal = v;
         }
         Type t = isObject? v.getType(context) : elementType;
         String tName = t.getName(context);
         if (newValues == null) {
            newValues = new ArrayList<>(len);
         }
      
         if (!supportedTypes.contains(tName)) {
            newValues.add(Integer.valueOf(0));
            continue;
         }
      
         if (isObject) {
            if (v.isNull()) {
               newValues.add(Integer.valueOf(0));
            }
            else {
               if (!t.equals(lastType)) {
                  if (tName.equals("java.awt.Color")) {
                     intValue = t.getMethod(context, "getRGB", "int", null);
                  }
                  else {
                     intValue = t.getMethod(context, "intValue", "int", null);
                  }
               }
               lastType = t;
               newValues.add(Integer.valueOf(v.invokeMethod(context, intValue, null).toInt(context)));
            }
         }
         else {
            newValues.add(Integer.valueOf(v.toInt(context)));
         }
      }
      newData.values = newValues;
      if (oldData != null && newValues != null) {
         boolean valueChanged = !oldData.obj.equals(newData.obj);
         newData.changed = new ArrayList<>(newValues.size());
         newData.isNew = new ArrayList<>(newValues.size());
         for (int i = 0; i < newValues.size(); i++) {
            boolean changed = !valueChanged && (i >= oldData.values.size()
                  || !oldData.values.get(i).equals(newValues.get(i)));
            newData.changed.add(Boolean.valueOf(changed));
            boolean isNew = valueChanged || i >= oldData.values.size();
            newData.isNew.add(Boolean.valueOf(isNew));
         }
      }
   
      newData.indexes = IndexItem.evalIndexExpressions(valueData.getIndexExpressions(),
            oldData == null ? null : oldData.indexes, context);
   
      stateData = newData;
   
      setSubViewValue(context, selVal, data.isReset());
   }
   
   
   /** Called before the painting of the bars starts. The default implementation does nothing. **/
   public void startBarPaint() {
   }
   
   
   /** Called during the painting of the bars, when a changed value is encountered. The default implementation does
    * nothing.
    *
    * @param index the index of the changed bar.
    *
    * @param size the number of elements in the graph.
    *
    * @param val the RGB value of the number. **/
   public void changedValue(final int index, final int size, final int val) {
   }
   
   
   /** Called after the painting of the bars starts. The default implementation does nothing. **/
   public void endBarPaint() {
   }
   
   
   /** {@inheritDoc} **/
   @Override
   public void buildGui(final JPanel main) {
      super.buildGui(main);
      main.addMouseListener(
         new MouseAdapter() {
         
            @Override
            public void mousePressed(final MouseEvent e) {
               if (barRect == null) {
                  return;
               }
            
               selInd = -1;
            
               int ind;
               Point pt = e.getPoint();
               javaToDrawing(pt);
               if (pt.y < barRect.y || pt.y > barRect.y + barRect.height) {
                  ind = -1;
               }
               else {
                  ind = (pt.x - barRect.x) / barRect.width;
               }
               if (ind == selInd) {
                  return;
               }
            
               selInd = ind;
               getVIData().update();
            }
         });
      ValueDragger.createValueDragger(main, getVIData(), 
         (pos)-> {
            if (selVal == null) {
               return null;
            }
            return new ValueDragData(null, selVal, null, getVIData().getScope(), getClass().getName());
         });
   }
}

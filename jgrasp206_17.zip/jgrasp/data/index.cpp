s
compiler environments
Microsoft Visual Studio (or Express)
 !E\  0=  6B   ]
c++ (g++) - Mac OS X
  O<  ,.  0^  !C
g++ - generic
  0F  .(  /J  ""
DJGPP2
 !2X  ,R  3$  ":
Borland BCC 5.5 - Windows
      ,P  0F  #%
Sun CC - Solaris
  @0  ,M  /,  #G
g++ - MinGW - OpenGL32 with freeglut
 "6^  .2  :X  $=
g++ - generic - Insight debugger
 ! :  .%  2>  %/
g++ - generic - OpenGL with GLUT
 !\>  .Q  :@  &!
clang - generic
 "QV  ..  :H  &B
